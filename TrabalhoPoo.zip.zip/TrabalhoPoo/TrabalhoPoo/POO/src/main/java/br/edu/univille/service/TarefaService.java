package br.edu.univille.service;

import br.edu.univille.dao.DeverDao;
import br.edu.univille.model.Dever;

import javax.swing.*;
import java.time.LocalDate;

public class TarefaService {

    private final DeverDao deverDao;

    public TarefaService (DeverDao deverDao) {
        this.deverDao = deverDao;
    }

    public void adicionarTarefaEmUmaLista(Dever dever) {

        if (dever.getTitulo().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, insira um título para a tarefa");
            throw new IllegalArgumentException("O título da tarefa não pode ser vazio");
        }

        if(dever.isConcluida()){
            dever.setDataConclusao(LocalDate.now());
        }

        dever.setId(deverDao.getProximoId());
        deverDao.create(dever);
    }

    public void concluirTarefa(int idTarefa) {
        Dever dever = deverDao.readOne(idTarefa);
        dever.setConcluida(true);
        dever.setDataConclusao(LocalDate.now());
        deverDao.update(dever);
    }

    public void desfazerTarefa(int idTarefa) {
        Dever dever = deverDao.readOne(idTarefa);
        dever.setConcluida(false);
        dever.setDataConclusao(null);
        deverDao.update(dever);
    }

    public void excluirTarefa(int idTarefa) {
        Dever dever = deverDao.readOne(idTarefa);
        deverDao.delete(dever.getId());
    }

    public void atualizarTarefa(int idTarefaOld, Dever deverNew) {
        Dever deverOld = deverDao.readOne(idTarefaOld);
        deverDao.update(deverNew);
    }

    public Dever listarUmaTarefa(int idTarefa) {
        Dever dever = deverDao.readOne(idTarefa);
        return dever;
    }
}
