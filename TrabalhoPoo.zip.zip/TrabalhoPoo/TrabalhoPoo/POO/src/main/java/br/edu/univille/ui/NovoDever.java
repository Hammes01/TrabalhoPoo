package br.edu.univille.ui;


import br.edu.univille.model.Lista;
import br.edu.univille.model.Dever;
import br.edu.univille.service.ListaService;
import br.edu.univille.service.TarefaService;

import javax.swing.*;
import java.awt.*;

public class NovoDever extends JFrame {

    private final ListaService listaService;
    private final TarefaService tarefaService;

    private JButton btnSalvar;
    private JButton btnCancelar;
    private JTextArea txtTitulo;
    private JTextArea txtTexto;
    private int comboPrioridade;
    private JCheckBox checkConcluida;
    private Lista lista;

    public NovoDever(ListaService listaService, TarefaService tarefaService, Lista lista) {

        this.listaService = listaService;
        this.tarefaService = tarefaService;
        this.lista = lista;

        setTitle("Novos Deveres");
        setSize(500, 500);
        setLayout(null);
        setResizable(false);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        this.txtTitulo = UtilsMethods.newJtextArea(50, 50, 25, 380, "Titulo", this);
        this.txtTexto = UtilsMethods.newJtextArea(50, 100, 190, 380, "Tarefa", this);
        this.comboPrioridade = this.campoSelectionPrioridade();
        this.checkConcluida = UtilsMethods.newCheckBox(50, 350, 10, 20, "Finalizado", this);
        this.btnCancelar = UtilsMethods.newBtn(200, 425, 20, 100, "Cancelar", this);
        this.btnSalvar = UtilsMethods.newBtn(325, 425, 20, 100, "Salvar", this);

        this.cancelarTarefa();
        this.salvarTarefa();

    }

    private void cancelarTarefa() {
        btnCancelar.addActionListener(e -> {
            this.dispose();
            new TelaDeveres(listaService, tarefaService, lista);
        });
    }

    private void salvarTarefa() {
        btnSalvar.addActionListener(e -> {

            Dever dever = new Dever();
            dever.setTitulo(txtTitulo.getText());
            dever.setConcluida(checkConcluida.isSelected());
            dever.setTexto(txtTexto.getText());
            // tarefa.setPrioridade(comboBoxIndexSelect);
            dever.setLista(lista);

            tarefaService.adicionarTarefaEmUmaLista(dever);

            this.dispose();
            new TelaDeveres(listaService, tarefaService, lista);
        });

    }

    private int campoSelectionPrioridade() {
        Label labelPrioridade = new Label("Prioridade");
        labelPrioridade.setBounds(50, 280, 70, 10);
        add(labelPrioridade);

        JComboBox comboBoxPrioridade = new JComboBox();
        comboBoxPrioridade.setBounds(50, 300, 375, 30);
        comboBoxPrioridade.addItem("Baixa");
        comboBoxPrioridade.addItem("Média");
        comboBoxPrioridade.addItem("Alta");
        add(comboBoxPrioridade);

        return comboBoxPrioridade.getSelectedIndex();
    }
}
