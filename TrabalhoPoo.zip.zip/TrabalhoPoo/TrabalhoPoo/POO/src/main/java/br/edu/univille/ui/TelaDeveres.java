package br.edu.univille.ui;

import br.edu.univille.model.Lista;
import br.edu.univille.model.Dever;
import br.edu.univille.service.ListaService;
import br.edu.univille.service.TarefaService;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class TelaDeveres extends JFrame {
    private final ListaService listaService;
    private final TarefaService tarefaService;

    private JButton btnCancelar;

    public TelaDeveres(ListaService listaService, TarefaService tarefaService, Lista lista) {

        this.listaService = listaService;
        this.tarefaService = tarefaService;

        setTitle("Lista de Deveres da Tarefa: " + lista.getTitulo());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 450);
        setResizable(false);
        setLayout(null);
        setLocationRelativeTo(null);
        setVisible(true);

        this.btnCancelar = UtilsMethods.newBtn(515, 350, 20, 90, "Voltar", this);
        this.btnCancelar.setFont(new java.awt.Font("Arial", 1, 15));

        ArrayList<Dever> devers = listaService.listarUmaListaPeloId(lista.getId()).getTarefas();
        List<Object> listObjects = UtilsMethods.newJTableByListTarefas(devers, listaService, tarefaService,this);

        JTable table = (JTable) listObjects.get(0);
        JScrollPane scrollPane = (JScrollPane) listObjects.get(1);
        table.setBounds(50, 50, 600, 250);


        JButton btnNewTarefa = UtilsMethods.newWindowPanel(50, 350, 20, 140, "Adicionar Dever", this, new NovoDever(listaService, tarefaService, lista));
        btnNewTarefa.setFont(new java.awt.Font("Arial", 1, 13));

        this.labelJtable();
        this.cancelarTarefa();
    }

    private void cancelarTarefa() {
        btnCancelar.addActionListener(e -> {
            this.dispose();
            new TelaInicial(listaService, tarefaService);
        });
    }

    public void labelJtable() {
        JLabel label1 = new JLabel("ID");
        JLabel label2 = new JLabel("Título");
        JLabel label3 = new JLabel("Deveres");
        JLabel label4 = new JLabel("Iniciação");
        JLabel label5 = new JLabel("Finalizado");

        label1.setBounds(50, 25, 50, 25);
        label2.setBounds(160, 25, 50, 25);
        label3.setBounds(240, 25, 150, 25);
        label4.setBounds(323, 25, 150, 25);
        label5.setBounds(405, 25, 150, 25);

        this.add(label1);
        this.add(label2);
        this.add(label3);
        this.add(label4);
        this.add(label5);

    }
}
